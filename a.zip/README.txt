📦 Cara Menjalankan Bot Telegram Logo (Kualitas Tinggi)

1. Install Python 3.8+ dan pip
2. Install dependensi dengan:
   pip install -r requirements.txt

3. Ubah file bot.py:
   Ganti 'YOUR_BOT_TOKEN_HERE' dengan token dari @BotFather kamu

4. Jalankan bot:
   python bot.py

Catatan:
- Bot ini akan menambahkan dua logo di kiri atas dan kanan atas
- Hasil disimpan sebagai JPEG kualitas tinggi (quality=100)
- File dikirim kembali ke user sebagai dokumen (tidak dikompres Telegram)
